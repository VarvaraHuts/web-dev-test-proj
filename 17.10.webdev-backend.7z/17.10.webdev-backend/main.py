from flask import Flask, request, json, render_template

app = Flask(__name__)

@app.route("/hello")
@app.route("/hello/<text>")
def hello(text=None):
    some_list = range(5)
    if text and len(text) > 4:
     template_name = "supertest.html"
    else:
     template_name = "index.html"
    return render_template(template_name, text=text, some_list=some_list)


@app.route("/")
def index():
    return json.jsonify({"a":"Hello"})

if __name__ == "__main__":
    app.run(debug=True)